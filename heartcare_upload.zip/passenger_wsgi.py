"""
WSGI entry point for cPanel Python hosting (Phusion Passenger).
This file is required for deploying Flask apps on cPanel.
"""

import sys
import os

# Add the project directory to the Python path
INTERP = os.path.expanduser("~/virtualenv/WebLab_Final_Project/3.9/bin/python3")
if sys.executable != INTERP:
    os.execl(INTERP, INTERP, *sys.argv)

sys.path.insert(0, os.path.dirname(__file__))

from app import app as application
